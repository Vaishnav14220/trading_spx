"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// netlify/functions/capital-auth.ts
var capital_auth_exports = {};
__export(capital_auth_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(capital_auth_exports);
var BASE_URL = "https://api-capital.backend-capital.com";
var handler = async (event) => {
  const headers = {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Headers": "Content-Type",
    "Access-Control-Allow-Methods": "POST, OPTIONS",
    "Content-Type": "application/json"
  };
  if (event.httpMethod === "OPTIONS") {
    return {
      statusCode: 200,
      headers,
      body: ""
    };
  }
  if (event.httpMethod !== "POST") {
    return {
      statusCode: 405,
      headers,
      body: JSON.stringify({ error: "Method not allowed" })
    };
  }
  try {
    const apiKey = process.env.CAPITAL_API_KEY;
    const identifier = process.env.CAPITAL_IDENTIFIER;
    const password = process.env.CAPITAL_PASSWORD;
    if (!apiKey || !identifier || !password) {
      return {
        statusCode: 500,
        headers,
        body: JSON.stringify({
          error: "Server configuration error: Missing credentials",
          details: "Please configure CAPITAL_API_KEY, CAPITAL_IDENTIFIER, and CAPITAL_PASSWORD in Netlify environment variables"
        })
      };
    }
    const response = await fetch(`${BASE_URL}/api/v1/session`, {
      method: "POST",
      headers: {
        "X-CAP-API-KEY": apiKey,
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        identifier,
        password,
        encryptedPassword: false
      })
    });
    if (!response.ok) {
      const errorText = await response.text();
      return {
        statusCode: response.status,
        headers,
        body: JSON.stringify({
          error: "Authentication failed",
          details: errorText
        })
      };
    }
    const cst = response.headers.get("CST");
    const securityToken = response.headers.get("X-SECURITY-TOKEN");
    if (!cst || !securityToken) {
      return {
        statusCode: 500,
        headers,
        body: JSON.stringify({ error: "Authentication tokens not received" })
      };
    }
    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({
        cst,
        securityToken
      })
    };
  } catch (error) {
    console.error("Error in capital-auth function:", error);
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({
        error: "Internal server error",
        details: error instanceof Error ? error.message : "Unknown error"
      })
    };
  }
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
