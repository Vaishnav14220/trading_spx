"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// netlify/functions/capital-proxy.ts
var capital_proxy_exports = {};
__export(capital_proxy_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(capital_proxy_exports);
var BASE_URL = "https://api-capital.backend-capital.com";
var handler = async (event) => {
  const headers = {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Headers": "Content-Type, CST, X-SECURITY-TOKEN",
    "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
    "Content-Type": "application/json"
  };
  if (event.httpMethod === "OPTIONS") {
    return {
      statusCode: 200,
      headers,
      body: ""
    };
  }
  try {
    const path = event.queryStringParameters?.path || "";
    const cst = event.headers["cst"] || "";
    const securityToken = event.headers["x-security-token"] || "";
    if (!cst || !securityToken) {
      return {
        statusCode: 401,
        headers,
        body: JSON.stringify({ error: "Missing authentication tokens" })
      };
    }
    const url = `${BASE_URL}${path}`;
    const response = await fetch(url, {
      method: event.httpMethod,
      headers: {
        "CST": cst,
        "X-SECURITY-TOKEN": securityToken,
        "Content-Type": "application/json"
      },
      body: event.body || void 0
    });
    const data = await response.text();
    return {
      statusCode: response.status,
      headers,
      body: data
    };
  } catch (error) {
    console.error("Error in capital-proxy function:", error);
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({
        error: "Proxy error",
        details: error instanceof Error ? error.message : "Unknown error"
      })
    };
  }
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
